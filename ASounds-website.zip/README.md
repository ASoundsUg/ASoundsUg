# ASounds

A lightweight music-discovery landing site designed for free static hosting.

## Files
- `index.html` — homepage
- `song.html` — reusable song-page template
- `style.css` — responsive styling

## How to use
1. Replace the demo song names and artists in `index.html`.
2. Duplicate `song.html` for individual songs, e.g. `artist-song.html`.
3. Change the title, artist, description and the official website URL.
4. Upload the files to GitHub Pages, Netlify, or another static host.

The template does not copy music files. Use official/authorized embeds or links.
